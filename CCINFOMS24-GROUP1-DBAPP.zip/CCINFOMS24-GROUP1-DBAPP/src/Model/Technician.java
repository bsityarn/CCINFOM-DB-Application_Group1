/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author marcquizon
 */
public class Technician {

    private String technicianID;
    private String firstName;
    private String lastName;
    private String email;
    private String position;
    private String currentPassword;
    private String newPassword;
    private String status;

    public static DefaultTableModel displayReport(String month, String year) {
        DefaultTableModel model = new DefaultTableModel();
        StringBuilder query = new StringBuilder();
        query.append(" SELECT\n"
                + "	t.technicianID,\n"
                + "    CONCAT(t.firstName, ' ', t.lastName) AS Name,\n"
                + "    COALESCE(p.Total_Patches, 0) AS Total_Patches_Released,\n"
                + "    ROUND(IFNULL(p.Working_Patches / p.Total_Patches *100, 0), 2) AS '%WorkingPatches',\n"
                + "	ROUND(IFNULL(p.NotWorking_Patches / p.Total_Patches *100, 0), 2) AS '%NotWorkingPatches',\n"
                + "    \n"
                + "    COALESCE(m.Total_Maintenance, 0) AS Total_MaintenanceAssigned,\n"
                + "	COALESCE(m.Pending_Maintenance, 0) AS Total_Pending,\n"
                + "	COALESCE(m.Completed_Maintenance, 0) AS Total_Completed,\n"
                + "    ROUND(IFNULL(m.Late_Maintenance / m.Completed_Maintenance * 100, 0), 2) AS '%Late_completed',\n"
                + "    ROUND(IFNULL(m.Punctual_Maintenance / m.Completed_Maintenance *100, 0), 2) AS '%Punctual_completed'\n"
                + "\n"
                + "FROM technicians t\n"
                + "\n"
                + "LEFT JOIN (\n"
                + "	SELECT\n"
                + "    technicianID,\n"
                + "    COUNT(*) AS Total_Patches,\n"
                + "    SUM(CASE WHEN status = 'Working' THEN 1 ELSE 0 END) AS Working_Patches,\n"
                + "    SUM(CASE WHEN status = 'Not Working' THEN 1 ELSE 0 END) AS NotWorking_Patches\n"
                + "    FROM patch\n"
                + "    WHERE MONTH(releaseDate) = ? \n"
                + "	AND YEAR(releaseDate) = ?\n"
                + "    GROUP BY technicianID\n"
                + ") p ON p.technicianID = t.technicianID\n"
                + "\n"
                + "LEFT JOIN(\n"
                + "	SELECT\n"
                + "    technicianIDassigned,\n"
                + "    COUNT(*) AS Total_Maintenance,\n"
                + "    SUM(CASE WHEN status IN ('In progress', 'Not Started') THEN 1 ELSE 0 END) AS Pending_Maintenance,\n"
                + "    SUM(CASE WHEN status = 'Done' THEN 1 ELSE 0 END) AS Completed_Maintenance,\n"
                + "    SUM(CASE WHEN status = 'Done' AND dateFinished > targetDeadline THEN 1 ELSE 0 END) AS Late_Maintenance,\n"
                + "    SUM(CASE WHEN status = 'Done' AND dateFinished < targetDeadline THEN 1 ELSE 0 END) AS Punctual_Maintenance\n"
                + "    \n"
                + "    FROM maintenance\n"
                + "    WHERE MONTH(dateAssigned) = ? \n"
                + "	AND YEAR(dateAssigned) = ?\n"
                + "    GROUP BY technicianIDassigned\n"
                + ") m ON m.technicianIDassigned = t.technicianID;");

        try (Connection conn = MySQLConnector.connectDB(); PreparedStatement statement = conn.prepareStatement(query.toString())) {
            statement.setString(1, month);
            statement.setString(2, year);
            statement.setString(3, month);
            statement.setString(4, year);


            // Execute query inside the try block
            try (ResultSet rs = statement.executeQuery()) {

                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                Vector<String> columnNames = new Vector<>();

                for (int i = 1; i <= columnCount; i++) {
                    columnNames.add(metaData.getColumnName(i));
                }

                model.setColumnIdentifiers(columnNames);

                int rowCount = 0;
                while (rs.next()) {
                    rowCount++;
                    Vector<Object> rowData = new Vector<>();
                    for (int i = 1; i <= columnCount; i++) {
                        rowData.add(rs.getObject(i));
                    }
                    model.addRow(rowData);
                }

                System.out.println("Technician Performance Report Rows found: " + rowCount);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }

        return model;
    }

    public static DefaultTableModel displayRecord(String technicianID) {
        DefaultTableModel model = new DefaultTableModel();
        StringBuilder query = new StringBuilder();
        query.append(" SELECT * FROM technicians ");
        query.append(" WHERE technicianID = ? ");

        try (Connection conn = MySQLConnector.connectDB(); PreparedStatement statement = conn.prepareStatement(query.toString())) {

            statement.setString(1, technicianID);

            // Execute query inside the try block
            try (ResultSet rs = statement.executeQuery()) {

                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                Vector<String> columnNames = new Vector<>();

                for (int i = 1; i <= columnCount; i++) {
                    columnNames.add(metaData.getColumnName(i));
                }

                model.setColumnIdentifiers(columnNames);

                int rowCount = 0;
                while (rs.next()) {
                    rowCount++;
                    Vector<Object> rowData = new Vector<>();
                    for (int i = 1; i <= columnCount; i++) {
                        rowData.add(rs.getObject(i));
                    }
                    model.addRow(rowData);
                }

                System.out.println("Technician Rows found: " + rowCount);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }

        return model;
    }

    public static DefaultTableModel displayTable() {
        DefaultTableModel model = new DefaultTableModel();
        StringBuilder query = new StringBuilder();
        query.append(" SELECT * FROM technicians ");

        try (Connection conn = MySQLConnector.connectDB(); PreparedStatement statement = conn.prepareStatement(query.toString())) {

            // Execute query inside the try block
            try (ResultSet rs = statement.executeQuery()) {

                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                Vector<String> columnNames = new Vector<>();

                for (int i = 1; i <= columnCount; i++) {
                    columnNames.add(metaData.getColumnName(i));
                }

                model.setColumnIdentifiers(columnNames);

                int rowCount = 0;
                while (rs.next()) {
                    rowCount++;
                    Vector<Object> rowData = new Vector<>();
                    for (int i = 1; i <= columnCount; i++) {
                        rowData.add(rs.getObject(i));
                    }
                    model.addRow(rowData);
                }

                System.out.println("Technician Rows found: " + rowCount);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }

        return model;
    }

    public static boolean checkEmailDuplicates(String email, String technicianID) {//used when editing a technician
        StringBuilder query = new StringBuilder();
        query.append(" SELECT  *               ");
        query.append(" FROM    technicians ");
        query.append(" WHERE   email = ? AND technicianID != ?");//Exempts the record of the technician we are editing
        Boolean duplicateResult = false;

        try {
            // Establish connection to DB
            Connection conn = MySQLConnector.connectDB();

            PreparedStatement statement = conn.prepareStatement(query.toString());

            statement.setString(1, email);
            statement.setString(2, technicianID);

            // 1. Use executeQuery() and get the ResultSet
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {//This command will return true when AT LEAST 1 record is found. Hence, duplicate is true
                duplicateResult = true;
            }

            //Closing the connections to avoid DB app slow down in performance
            rs.close();
            statement.close();
            conn.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return duplicateResult;
    }

    public static boolean checkEmailDuplicates(String email) {//used when adding a new technician, no ID yet
        StringBuilder query = new StringBuilder();
        query.append(" SELECT  *               ");
        query.append(" FROM    technicians ");
        query.append(" WHERE   email = ? ");
        Boolean duplicateResult = false;

        try {
            // Establish connection to DB
            Connection conn = MySQLConnector.connectDB();

            PreparedStatement statement = conn.prepareStatement(query.toString());

            statement.setString(1, email);

            // 1. Use executeQuery() and get the ResultSet
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {//This command will return true when AT LEAST 1 record is found. Hence, duplicate is true
                duplicateResult = true;
            }

            //Closing the connections to avoid DB app slow down in performance
            rs.close();
            statement.close();
            conn.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return duplicateResult;
    }

    public static boolean checkMatchCurrentPassword(String technicianID, String passwordFromInput) {
        StringBuilder query = new StringBuilder();
        query.append(" SELECT  password               ");
        query.append(" FROM    technicians ");
        query.append(" WHERE   technicianID = ? ");
        Boolean matchResult = false;

        try {
            // Establish connection to DB
            Connection conn = MySQLConnector.connectDB();

            PreparedStatement statement = conn.prepareStatement(query.toString());

            statement.setString(1, technicianID);

            // 1. Use executeQuery() and get the ResultSet
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {//This command will return true when AT LEAST 1 record is found.
                String passwordFromDB = rs.getString("password");//We get the password from the database
                if (passwordFromDB.equals(passwordFromInput)) {//We compare them and ensure they match
                    matchResult = true;
                }
            }

            //Closing the connections to avoid DB app slow down in performance
            rs.close();
            statement.close();
            conn.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return matchResult;
    }

    public static boolean login(String technicianID, char[] password) {
        StringBuilder query = new StringBuilder();
        query.append(" SELECT  *               ");
        query.append(" FROM    technicians ");
        query.append(" WHERE   technicianID = ? ");
        Boolean result = false;
        String typedPassword = new String(password);
        try {
            // Establish connection to DB
            Connection conn = MySQLConnector.connectDB();

            // Prepare SQL statement to be executed
            PreparedStatement statement = conn.prepareStatement(query.toString());

            statement.setString(1, technicianID);
            // 1. Use executeQuery() and get the ResultSet
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {//"if (rs.next)" will return true when AT LEAST 1 record is found. Hence, the technician is found
                String passwordFromDB = rs.getString("password");
                if (passwordFromDB.equals(typedPassword)) {//Checks if the right password was inputted
                    result = true;
                } else {
                    result = false;
                }
            }

            rs.close();
            statement.close();
            conn.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            result = false;
        }
        return result;
    }

    public static String add(String firstName, String lastName, String email, String position, String password) {
        String incrementedID = "";
        StringBuilder query = new StringBuilder();
        query.append(" INSERT INTO technicians (technicianID, firstName, lastName, position, email, password) ");
        query.append(" VALUES (?, ?, ?, ?, ?, ?)");

        if (firstName.isBlank() || lastName.isBlank() || email.isBlank() || password.isBlank()) {//Checker for when the User leaves a Field blank
            return "Empty";
        } else if (checkEmailDuplicates(email) == true) {//Checker for email duplicates
            return "Duplicate Email";
        } else {
            try {
                // Establish connection to DB
                Connection conn = MySQLConnector.connectDB();

                // Prepare SQL statement to be executed
                PreparedStatement statement = conn.prepareStatement(query.toString());

                incrementedID = HelperFunctions.incrementID("technicians");
                statement.setString(1, incrementedID);
                statement.setString(2, firstName);
                statement.setString(3, lastName);
                statement.setString(4, position);
                statement.setString(5, email);
                statement.setString(6, password);

                statement.executeUpdate();

                statement.close();
                conn.close();

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return "Invalid";
            }
        }
        return incrementedID;//We return the incrementedID, so the sign up frame can show the user their ID credential
    }

    public static String edit(String technicianID, String firstName, String lastName, String email, String position, String currentPassword, String newPassword) {
        StringBuilder query1 = new StringBuilder();//This command is used when the user wants to keep the password the same
        query1.append("UPDATE technicians ");
        query1.append("SET firstName = ?, lastName = ?, position = ?, email = ? ");
        query1.append("WHERE technicianID = ?");

        StringBuilder query2 = new StringBuilder();//This command is used when the user want to change their password
        query2.append("UPDATE technicians ");
        query2.append("SET firstName = ?, lastName = ?, position = ?, email = ?, password = ? ");
        query2.append("WHERE technicianID = ?");

        //Checker for when the User leaves a Field blank
        //We allow the currentPassword and newPassword field to BOTH be blank, but we do not allow ONLY 1 of them to be blank
        if (firstName.isBlank() || lastName.isBlank() || email.isBlank()
                || (currentPassword.isBlank() && !newPassword.isBlank()) || (!currentPassword.isBlank() && newPassword.isBlank())) {
            return "Empty";
        } else if (checkEmailDuplicates(email, technicianID) == true) {//Checker for email duplicates
            return "Duplicate Email";
        } else if (currentPassword.isBlank() && newPassword.isBlank()) {
            try {
                // Establish connection to DB
                Connection conn = MySQLConnector.connectDB();

                // Prepare SQL statement to be executed
                PreparedStatement statement1 = conn.prepareStatement(query1.toString());

                statement1.setString(1, firstName);
                statement1.setString(2, lastName);
                statement1.setString(3, position);
                statement1.setString(4, email);
                statement1.setString(5, technicianID);

                statement1.executeUpdate();

                statement1.close();
                conn.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return "Invalid";
            }
        } else if (checkMatchCurrentPassword(technicianID, currentPassword) == true) {
            try {
                // Establish connection to DB
                Connection conn = MySQLConnector.connectDB();

                // Prepare SQL statement to be executed
                PreparedStatement statement2 = conn.prepareStatement(query2.toString());

                statement2.setString(1, firstName);
                statement2.setString(2, lastName);
                statement2.setString(3, position);
                statement2.setString(4, email);
                statement2.setString(5, newPassword);
                statement2.setString(6, technicianID);

                statement2.executeUpdate();

                statement2.close();
                conn.close();

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return "Invalid";
            }
        } else if (checkMatchCurrentPassword(technicianID, currentPassword) == false) {
            return "Wrong password";
        }
        return "Valid";
    }

    public static String delete(String technicianID) {
        StringBuilder query = new StringBuilder();
        query.append(" UPDATE technicians               ");
        query.append(" SET   status = 'Inactive' ");
        query.append(" WHERE   technicianID = ? ");

        String result = "Invalid";

        if (technicianID.isBlank()) {
            result = "Empty";
        } else {
            try {
                // Establish connection to DB
                Connection conn = MySQLConnector.connectDB();

                // Prepare SQL statement to be executed
                PreparedStatement statement = conn.prepareStatement(query.toString());

                statement.setString(1, technicianID);
                int rowAffected = statement.executeUpdate();
                System.out.println(rowAffected);

                if (rowAffected == 0) {
                    result = "Missing";
                } else if (rowAffected > 0) {
                    result = "Valid";
                }
                statement.close();
                conn.close();

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                result = "Invalid";
            }
        }
        return result;
    }

    public static String activate(String technicianID) {
        StringBuilder query = new StringBuilder();
        query.append(" UPDATE technicians               ");
        query.append(" SET   status = 'Available' ");
        query.append(" WHERE   technicianID = ? ");

        String result = "Invalid";

        if (technicianID.isBlank()) {
            result = "Empty";
        } else {
            try {
                // Establish connection to DB
                Connection conn = MySQLConnector.connectDB();

                // Prepare SQL statement to be executed
                PreparedStatement statement = conn.prepareStatement(query.toString());

                statement.setString(1, technicianID);
                int rowAffected = statement.executeUpdate();
                System.out.println(rowAffected);

                if (rowAffected == 0) {
                    result = "Missing";
                } else if (rowAffected > 0) {
                    result = "Valid";
                }
                statement.close();
                conn.close();

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                result = "Invalid";
            }
        }
        return result;
    }

    public static Technician getInfo(String technicianID) {
        //TODO edit email part to get the first part and remove @ptrackerdb.com

        StringBuilder query = new StringBuilder();
        query.append(" SELECT  *               ");
        query.append(" FROM    technicians ");
        query.append(" WHERE   technicianID = ? ");
        Technician resultTechnician = new Technician();

        try {
            // Establish connection to DB
            Connection conn = MySQLConnector.connectDB();

            PreparedStatement statement = conn.prepareStatement(query.toString());

            statement.setString(1, technicianID);

            // 1. Use executeQuery() and get the ResultSet
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {//"if (rs.next)" will return true when AT LEAST 1 record is found. Hence, the technician is found
                resultTechnician.setID(rs.getString("technicianID"));
                resultTechnician.setFirstName(rs.getString("firstName"));
                resultTechnician.setLastName(rs.getString("lastName"));
                resultTechnician.setEmail(rs.getString("email"));
                resultTechnician.setPosition(rs.getString("position"));
                resultTechnician.setStatus(rs.getString("status"));
            }

            //Closing the connections to avoid DB app slow down in performance
            rs.close();
            statement.close();
            conn.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return resultTechnician;
    }
    
    public static Technician getByID(String technicianID) {
        Technician tech = new Technician();
        String query = "SELECT * FROM technicians WHERE technicianID=?";
        try (Connection conn = MySQLConnector.connectDB();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, technicianID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                tech.setID(rs.getString("technicianID"));
                tech.setFirstName(rs.getString("firstName"));
                tech.setLastName(rs.getString("lastName"));
                tech.setEmail(rs.getString("email"));
                tech.setPosition(rs.getString("position"));
                tech.setStatus(rs.getString("status"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return tech;
    }

    public String getName() {
        return this.firstName + " " + this.lastName;
    }

    // --- Getters ---
    public String getTechnicianID() {
        return technicianID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPosition() {
        return position;
    }

    public String getCurrentPassword() {
        return currentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public String getStatus() {
        return status;
    }

    // --- Setters ---
    public void setID(String technicianID) {
        this.technicianID = technicianID;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setCurrentPassword(String currentPassword) {
        this.currentPassword = currentPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
